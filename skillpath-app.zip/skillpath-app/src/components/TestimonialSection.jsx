import React from 'react';

const defaultTestimonials = [
  {
    name: 'Priya Sharma',
    role: 'Frontend Developer',
    quote:
      'SkillPath gave me the structure and confidence I needed to land my first developer role.',
    avatar: '👩‍💻',
  },
  {
    name: 'Arjun Mehta',
    role: 'Product Designer',
    quote:
      'The hands-on projects made all the difference. I actually built things, not just watched videos.',
    avatar: '🧑‍🎨',
  },
  {
    name: 'Sara Khan',
    role: 'Data Analyst',
    quote:
      'Clear explanations and practical exercises helped me switch careers in just a few months.',
    avatar: '👩‍🔬',
  },
];

export default function TestimonialSection({ testimonials = defaultTestimonials }) {
  return (
    <section className="testimonial-section">
      <h2>What Our Learners Say</h2>
      <div className="testimonial-grid">
        {testimonials.map((t, idx) => (
          <div className="testimonial-card" key={idx}>
            <div className="testimonial-avatar">{t.avatar}</div>
            <p className="testimonial-quote">&ldquo;{t.quote}&rdquo;</p>
            <h4>{t.name}</h4>
            <span>{t.role}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
