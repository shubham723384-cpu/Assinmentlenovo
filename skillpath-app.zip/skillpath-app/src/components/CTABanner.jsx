import React from 'react';
import { Link } from 'react-router-dom';

export default function CTABanner({
  heading = 'Ready to Start Your Learning Journey?',
  subheading = 'Join thousands of learners building real skills with SkillPath.',
  buttonText = 'Contact Us',
  buttonLink = '/contact',
}) {
  return (
    <section className="cta-banner">
      <h2>{heading}</h2>
      <p>{subheading}</p>
      <Link to={buttonLink} className="btn btn-secondary">
        {buttonText}
      </Link>
    </section>
  );
}
