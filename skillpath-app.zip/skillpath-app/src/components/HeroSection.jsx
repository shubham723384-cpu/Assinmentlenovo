import React from 'react';
import { Link } from 'react-router-dom';

export default function HeroSection({
  title = 'Learn the Skills That Shape Your Future',
  subtitle = 'SkillPath helps you master in-demand skills through hands-on, project-based learning.',
  ctaText = 'Get Started',
  ctaLink = '/contact',
}) {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <h1>{title}</h1>
        <p>{subtitle}</p>
        <Link to={ctaLink} className="btn btn-primary">
          {ctaText}
        </Link>
      </div>
    </section>
  );
}
