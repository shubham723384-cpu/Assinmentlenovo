import React from 'react';
import Navbar from '../components/Navbar.jsx';
import HeroSection from '../components/HeroSection.jsx';
import FeatureCard from '../components/FeatureCard.jsx';
import TestimonialSection from '../components/TestimonialSection.jsx';
import CTABanner from '../components/CTABanner.jsx';
import Footer from '../components/Footer.jsx';

const features = [
  {
    icon: '🚀',
    title: 'Project-Based Learning',
    description: 'Build real-world projects that strengthen your portfolio as you learn.',
  },
  {
    icon: '🧠',
    title: 'Expert-Led Content',
    description: 'Learn from curated lessons designed by industry professionals.',
  },
  {
    icon: '📈',
    title: 'Track Your Progress',
    description: 'Stay motivated with clear milestones and progress tracking.',
  },
];

export default function LandingPage() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />

        <section className="features-section">
          <h2>Why Choose SkillPath</h2>
          <div className="features-grid">
            {features.map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon} title={f.title} description={f.description} />
            ))}
          </div>
        </section>

        <TestimonialSection />
        <CTABanner />
      </main>
      <Footer />
    </>
  );
}
