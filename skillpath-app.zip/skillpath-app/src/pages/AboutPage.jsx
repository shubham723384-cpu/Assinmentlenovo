import React from 'react';
import Navbar from '../components/Navbar.jsx';
import Footer from '../components/Footer.jsx';

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="about-page">
        <section className="page-header">
          <h1>About SkillPath</h1>
          <p>Empowering learners to build real, job-ready skills.</p>
        </section>

        <section className="about-content">
          <h2>Our Purpose</h2>
          <p>
            SkillPath was created to bridge the gap between theoretical learning and real-world
            ability. We believe that the best way to learn a skill is by practicing it, so every
            course on our platform is built around hands-on, project-based work.
          </p>

          <h2>What We Offer</h2>
          <ul className="about-list">
            <li>Structured learning paths across multiple domains</li>
            <li>Hands-on projects that mirror real industry work</li>
            <li>Progress tracking to keep learners motivated</li>
            <li>A supportive community of mentors and peers</li>
          </ul>

          <h2>Key Features</h2>
          <div className="about-features">
            <div>
              <h3>Responsive Design</h3>
              <p>Learn anywhere — our platform adapts to any device.</p>
            </div>
            <div>
              <h3>Reusable Learning Modules</h3>
              <p>Each lesson builds on reusable concepts that compound your skills.</p>
            </div>
            <div>
              <h3>Modern Tooling</h3>
              <p>Get hands-on with the same tools used by professionals today.</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
