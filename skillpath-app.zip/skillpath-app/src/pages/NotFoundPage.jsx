import React from 'react';
import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="not-found-page">
      <h1>404</h1>
      <h2>Page Not Found</h2>
      <p>Sorry, the page you&rsquo;re looking for doesn&rsquo;t exist or has been moved.</p>
      <Link to="/" className="btn btn-primary">
        Back to Homepage
      </Link>
    </div>
  );
}
