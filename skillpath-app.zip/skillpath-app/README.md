# SkillPath Website Enhancement

A responsive multi-page React application built with reusable components and React Router, created for the "AI-Driven Web and Product Dev" capstone assignment.

## Setup

```bash
npm install
npm run dev
```

Then open the printed local URL (typically http://localhost:5173).

## Project Structure

```
src/
  components/
    Navbar.jsx
    Footer.jsx
    HeroSection.jsx
    FeatureCard.jsx
    TestimonialSection.jsx
    CTABanner.jsx
  pages/
    LandingPage.jsx
    AboutPage.jsx
    ContactPage.jsx
    NotFoundPage.jsx
  styles/
    global.css
  App.jsx
  main.jsx
```

## Routes

| Path       | Page          |
|------------|---------------|
| `/`        | LandingPage   |
| `/about`   | AboutPage     |
| `/contact` | ContactPage   |
| `*`        | NotFoundPage  |

## Notes

- The Contact form uses controlled inputs (`useState`), validates that all fields are filled (plus a basic email format check), calls `e.preventDefault()` on submit, and shows a success message on valid submission.
- Navbar and Footer both include Home / About / Contact links and are reused across all pages.
- Layout is responsive: feature cards, testimonials, and the footer collapse to a single column on small screens, and the navbar becomes a toggleable mobile menu.
